package com.user.service;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.user.dto.UserDTO;
import com.user.entity.Role;
import com.user.entity.User;
import com.user.exception.DataInsuffecientException;
import com.user.exception.RemoveUserException;
import com.user.exception.UserNotFoundException;
import com.user.repository.UserRepository;

@Service
public class UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);
        
    private MailService mailService;
    private UserRepository userRepo;
    private final JwtService jwtServ;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authManager;

    public UserService(UserRepository userRepo, JwtService jwtServ, PasswordEncoder passwordEncoder,
                       AuthenticationManager authManager, MailService mailService) {
        this.userRepo = userRepo;
        this.jwtServ = jwtServ;
        this.passwordEncoder = passwordEncoder;
        this.authManager = authManager;
        this.mailService = mailService;
    }

    public User register(User user) throws DataInsuffecientException {
        if (user != null) {
            logger.info("Registering new user: {}", user.getUsername());
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            user.setRole(Role.USER);
            userRepo.save(user);
            mailService.sendMail(user.getEmail(), "Welcome to Our App", "Hi " + user.getUsername() + ", thanks for registering!");
            return user;
        } else {
            logger.error("User registration failed: incomplete data");
            throw new DataInsuffecientException("No or incomplete values");
        }
    }

    public ResponseEntity<?> login(UserDTO userDTO) {
        try {
            logger.info("Authenticating user: {}", userDTO.getUsername());
            Authentication authentication = authManager.authenticate(
                    new UsernamePasswordAuthenticationToken(userDTO.getUsername(), userDTO.getPassword()));

            SecurityContextHolder.getContext().setAuthentication(authentication);
            User user1 = userRepo.findByUsername(userDTO.getUsername())
                    .orElseThrow(() -> new RuntimeException("Employee not found with given username"));

            String token = jwtServ.generateToken(user1.getUsername(), user1.getRole());
//            mailService.sendMail(userDTO.getUsername(), "Login Notification", "You have successfully logged in.");
            logger.info("Login successful for user: {}", user1.getUsername());
            return ResponseEntity.ok(Map.of("username: ", user1.getUsername(), "role: ", user1.getRole(), "token: ", token));
        } catch (Exception e) {
            logger.warn("Login failed for user: {}", userDTO.getUsername());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error: ", "Invalid credentials"));
        }
    }

    public User findByUsername(String username) throws UserNotFoundException {
        logger.debug("Searching for user: {}", username);
        return userRepo.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException("User not found"));
    }

    public String deleteUser(int id) throws RemoveUserException {
        logger.warn("Attempting to delete user with ID: {}", id);
        User user = userRepo.findById(id).orElse(null);

        if (user != null) {
            userRepo.delete(user);
            logger.info("Deleted user with ID: {}", id);
            return "Deleted user successfully";
        } else {
            logger.error("Failed to delete user with ID: {}", id);
            throw new RemoveUserException("Error deleting");
        }
    }
}