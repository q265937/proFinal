package com.user.entity;

public enum Role {
	USER, ADMIN;
}
