package com.user.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.user.entity.Role;
import com.user.entity.User;
import com.user.exception.DataInsuffecientException;
import com.user.exception.RemoveUserException;
import com.user.exception.UserNotFoundException;
import com.user.repository.UserRepository;

public class UserServiceTest {

    @Mock
    private UserRepository userRepo;

    @Mock
    private JwtService jwtServ;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private AuthenticationManager authManager;

    @InjectMocks
    private UserService userService;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegisterUser_Success() throws DataInsuffecientException {
        User user = new User();
        user.setUsername("testuser");
        user.setPassword("plainpass");

        when(passwordEncoder.encode("plainpass")).thenReturn("encodedpass");
        when(userRepo.save(any(User.class))).thenReturn(user);

        User registered = userService.register(user);

        assertEquals("testuser", registered.getUsername());
        assertEquals(Role.USER, registered.getRole());
        verify(userRepo).save(any(User.class));
    }

    @Test
    void testRegisterUser_NullInput() {
        assertThrows(RuntimeException.class, () -> userService.register(null));
    }



    @Test
    void testFindByUsername_Success() throws UserNotFoundException {
        User user = new User();
        user.setUsername("testuser");

        when(userRepo.findByUsername("testuser")).thenReturn(Optional.of(user));

        User found = userService.findByUsername("testuser");

        assertEquals("testuser", found.getUsername());
    }

    @Test
    void testFindByUsername_NotFound() {
        when(userRepo.findByUsername("unknown")).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> userService.findByUsername("unknown"));
    }

    @Test
    void testDeleteUser_Success() throws RemoveUserException {
        User user = new User();
        user.setId(1);

        when(userRepo.findById(1)).thenReturn(Optional.of(user));

        String result = userService.deleteUser(1);

        assertEquals("Deleted user successfully", result);
        verify(userRepo).delete(user);
    }

    @Test
    void testDeleteUser_NotFound() {
        when(userRepo.findById(99)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> userService.deleteUser(99));
    }
}