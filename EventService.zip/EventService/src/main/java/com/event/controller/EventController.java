package com.event.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.event.entity.Event;
import com.event.exception.DataInsuffecientException;
import com.event.exception.IdNotFoundException;
import com.event.exception.RemoveEventException;
import com.event.service.EventService;

@RestController
@RequestMapping("/event")
public class EventController {

    private static final Logger logger = LoggerFactory.getLogger(EventController.class);

    private EventService eventService;

    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @PostMapping("/add")
    public ResponseEntity<Event> addEvent(@RequestBody Event event) throws DataInsuffecientException {
        logger.info("Adding new event: {}", event.getEventName());
        Event eve = eventService.newEvent(event);
        return ResponseEntity.ok(eve);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Event>> allEvents() {
        logger.debug("Fetching all events");
        List<Event> eve = eventService.allEvents();
        return ResponseEntity.ok(eve);
    }

    @GetMapping("/findById/{id}")
    public ResponseEntity<Event> findById(@PathVariable int id) throws IdNotFoundException {
        logger.debug("Finding event by ID: {}", id);
        Event eve = eventService.findbyId(id);
        return ResponseEntity.ok(eve);
    }

    @DeleteMapping("/remove/{id}")
    public ResponseEntity<Event> removeEvents(@PathVariable int id) throws RemoveEventException {
        logger.warn("Removing event with ID: {}", id);
        Event eve = eventService.removeEvent(id);
        return ResponseEntity.ok(eve);
    }

//    @PostMapping("/bookSeat/{quantity}")
//    public ResponseEntity<Event> bookSeat(@RequestBody Event event, @PathVariable int quantity) {
//        logger.info("Booking {} seats for event ID: {}", quantity, event.getEventId());
//        Event eve = eventService.updateSeats(event, quantity);
//        return ResponseEntity.ok(eve);
//    }
}