package com.event.exception;

public class RemoveEventException extends Exception{

	public RemoveEventException(String message) {
		super(message);
	}
}
