package com.event.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.event.entity.Event;
import com.event.exception.DataInsuffecientException;
import com.event.exception.IdNotFoundException;
import com.event.exception.InvalidLocationException;
import com.event.exception.RemoveEventException;
import com.event.repository.EventRepository;

@Service
public class EventService {

    private static final Logger logger = LoggerFactory.getLogger(EventService.class);

    private EventRepository eventRepo;

    public EventService(EventRepository eventRepo) {
        this.eventRepo = eventRepo;
    }

    public Event newEvent(Event event) throws DataInsuffecientException{
        if (event != null) {
            logger.info("Saving new event: {}", event.getEventName());
            eventRepo.save(event);
            return event;
        } else {
            logger.error("Event creation failed: insufficient details");
            throw new DataInsuffecientException("Event details insufficeint");
        }
    }

    public List<Event> allEvents() {
        logger.debug("Retrieving all events");
        return eventRepo.findAll();
    }

    public Event removeEvent(int id) throws RemoveEventException {
        logger.warn("Attempting to remove event with ID: {}", id);
        Event event = eventRepo.findById(id).orElse(null);
        if (event != null) {
            eventRepo.delete(event);
            logger.info("Event removed: {}", event.getEventName());
            return event;
        } else {
            logger.error("Failed to remove event with ID: {}", id);
            throw new RemoveEventException("Error while removing event");
        }
    }

    public Event findbyId(int id) throws IdNotFoundException {
        logger.debug("Searching for event with ID: {}", id);
        Event event = eventRepo.findById(id).orElse(null);
        if (event != null) {
            return event;
        } else {
            logger.error("Event not found with ID: {}", id);
            throw new IdNotFoundException("Could not find event by ID:" + id);
        }
    }

    public Event updateLocation(String location, int id) throws InvalidLocationException {
        logger.info("Updating location for event ID: {} to {}", id, location);
        Event event = eventRepo.findById(id).orElse(null);
        if (event != null) {
            event.setLocation(location);
            eventRepo.save(event);
            return event;
        } else {
            logger.error("Invalid location update attempt for event ID: {}", id);
            throw new InvalidLocationException("Invalid Location");
        }
    }

    

//    public Event updateSeats(Event event, int quantity) {
//        logger.info("Updating seats for event ID: {} by reducing {}", event.getEventId(), quantity);
//        Event eventRes = eventRepo.findById(event.getEventId()).orElse(null);
//        if (eventRes != null) {
//        	eventRes.setNoOfSeats(eventRes.getNoOfSeats() - quantity);
//            return eventRepo.save(eventRes);
//        } else {
//            logger.error("Invalid seat update attempt for event ID: {}", event.getEventId());
//            throw new RuntimeException("Invalid Seats");
//        }
//    }
}