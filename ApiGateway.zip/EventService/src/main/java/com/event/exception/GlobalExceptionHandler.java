package com.event.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(DataInsuffecientException.class)
	public ResponseEntity<String> handleBookingIdNotFound(DataInsuffecientException ex){
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.EXPECTATION_FAILED);
	}
	
	@ExceptionHandler(IdNotFoundException.class)
	public ResponseEntity<String> handleBookingNotFound(IdNotFoundException ex){
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(InvalidLocationException.class)
	public ResponseEntity<String> handleInsufficientDataException(InvalidLocationException ex){
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(RemoveEventException.class)
	public ResponseEntity<String> handleInsufficientDataException(RemoveEventException ex){
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	}
	
}
