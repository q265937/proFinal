package com.booking.exception;

public class BookingIdNotFound extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3538104662033782885L;

	public BookingIdNotFound(String message) {
		super(message);
	}

}
