package com.user.exception;

public class UserNotFoundException extends Exception{
	
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 109309038660212868L;

	 public UserNotFoundException(String message) {
		super(message);
	}
	

}
