package com.user.exception;

public class RemoveUserException extends Exception{

	public RemoveUserException(String message) {
		super(message);
	}
}
