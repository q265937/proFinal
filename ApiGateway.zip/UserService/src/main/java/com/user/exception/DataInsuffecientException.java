package com.user.exception;

public class DataInsuffecientException extends Exception{

	public DataInsuffecientException(String message) {
		super(message);
	}
}
