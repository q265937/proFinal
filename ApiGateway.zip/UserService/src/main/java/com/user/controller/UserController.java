package com.user.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.user.dto.UserDTO;
import com.user.entity.User;
import com.user.exception.DataInsuffecientException;
import com.user.exception.RemoveUserException;
import com.user.exception.UserNotFoundException;
import com.user.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    private UserService userServ;

    public UserController(UserService userServ) {
        this.userServ = userServ;
    }

    @PostMapping("/register")
    public ResponseEntity<User> registerUser(@RequestBody User user) throws DataInsuffecientException {
        logger.info("Registering user: {}", user.getUsername());
        User result = userServ.register(user);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody UserDTO user) {
        logger.info("Login attempt for user: {}", user.getUsername());
        return ResponseEntity.ok(userServ.login(user));
    }

    @GetMapping("/find/{username}")
    public ResponseEntity<User> findUser(@PathVariable String username) throws UserNotFoundException {
        logger.debug("Finding user by username: {}", username);
        User user = userServ.findByUsername(username);
        return ResponseEntity.ok(user);
    }

    @DeleteMapping("/remove/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable int id) throws RemoveUserException {
        logger.warn("Deleting user with ID: {}", id);
        String response = userServ.deleteUser(id);
        return ResponseEntity.ok(response);
    }
}