package com.booking.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.booking.dto.EventDTO;
import com.booking.dto.UserDTO;
import com.booking.entity.Booking;
import com.booking.exception.BookingIdNotFound;
import com.booking.exception.BookingNotFoundException;
import com.booking.exception.InsufficientDataException;
import com.booking.service.BookingService;

@RestController
@RequestMapping("/booking")
public class BookingController {

    private static final Logger logger = LoggerFactory.getLogger(BookingController.class);

    private BookingService bookServ;

    public BookingController(BookingService bookServ) {
        this.bookServ = bookServ;
    }

    @PostMapping("/new/{username}")
    public ResponseEntity<Booking> newBooking(@RequestBody Booking booking, @PathVariable String username) throws InsufficientDataException {
        logger.info("Creating new booking for user: {}", username);
        Booking b = bookServ.newBooking(booking, username);
        return ResponseEntity.ok(b);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Booking>> allBookings() {
        logger.debug("Fetching all bookings");
        List<Booking> all = bookServ.allBookings();
        return ResponseEntity.ok(all);
    }

    @GetMapping("/findByEvent/{eventName}")
    public ResponseEntity<Booking> findByEventName(@PathVariable String eventName) throws BookingNotFoundException {
        logger.debug("Finding booking by event name: {}", eventName);
        Booking b = bookServ.findBookingByEventName(eventName);
        return ResponseEntity.ok(b);
    }

    @GetMapping("/findById/{id}")
    public ResponseEntity<Booking> findBookingById(@PathVariable int bookingId) throws BookingIdNotFound {
        logger.debug("Finding booking by ID: {}", bookingId);
        Booking b = bookServ.findBooking(bookingId);
        return ResponseEntity.ok(b);
    }

    @GetMapping("/user/{username}")
    public ResponseEntity<UserDTO> userData(@PathVariable String username) {
        logger.debug("Fetching user data for: {}", username);
        return ResponseEntity.ok(bookServ.findByUsername(username));
    }

    @GetMapping("/event/findById/{id}")
    public ResponseEntity<EventDTO> eventData(@PathVariable int id) {
        logger.debug("Fetching event data for ID: {}", id);
        return ResponseEntity.ok(bookServ.findById(id));
    }

//    @PutMapping("/event/bookSeat/{id}/{quantity}")
//    public ResponseEntity<EventDTO> setQuantity(@PathVariable int id, @PathVariable int quantity) {
//        logger.info("Booking {} seats for event ID: {}", quantity, id);
//        return ResponseEntity.ok(bookServ.setQuantity(id, quantity));
//    }
}