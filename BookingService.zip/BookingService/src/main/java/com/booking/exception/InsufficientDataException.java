package com.booking.exception;

public class InsufficientDataException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7085496071987377681L;

	public InsufficientDataException(String message) {
		super(message);
	}

}
