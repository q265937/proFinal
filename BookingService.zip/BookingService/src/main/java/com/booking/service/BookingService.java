package com.booking.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.dto.EventDTO;
import com.booking.dto.UserDTO;
import com.booking.entity.Booking;
import com.booking.exception.BookingIdNotFound;
import com.booking.exception.BookingNotFoundException;
import com.booking.exception.InsufficientDataException;
import com.booking.interservices.EventClient;
import com.booking.interservices.UserClient;
import com.booking.repository.BookingRepository;

@Service
public class BookingService {

    private static final Logger logger = LoggerFactory.getLogger(BookingService.class);

    private BookingRepository bookRepo;

    @Autowired
    private UserClient userClient;

    @Autowired
    private EventClient eventClient;

    public BookingService(BookingRepository bookRepo) {
        this.bookRepo = bookRepo;
    }

    public Booking newBooking(Booking booking, String username) throws InsufficientDataException {
        logger.info("Attempting to create booking for user: {}", username);
        UserDTO userDTO = userClient.findUser(username);
        //EventDTO result = setQuantity(id, booking.getNoOfSeats());
        //eventClient.updateSeats(result, booking.getNoOfSeats());
        if (userDTO != null) {
            booking.setUsername(username);
            booking.setPrice(booking.getPrice() * booking.getNoOfSeats());
            
            bookRepo.save(booking);
            logger.info("Booking created successfully for user: {}", username);
            return booking;
        } else {
            logger.error("Booking creation failed: user data not found for {}", username);
            throw new InsufficientDataException("Booking data insufficient");
        }
    }

    public List<Booking> allBookings() {
        logger.debug("Retrieving all bookings");
        return bookRepo.findAll();
    }

    public Booking findBooking(int bookingId) throws BookingIdNotFound {
        logger.debug("Searching for booking with ID: {}", bookingId);
        return bookRepo.findById(bookingId)
                .orElseThrow(() -> {
                    logger.error("Booking not found for ID: {}", bookingId);
                    return new BookingIdNotFound("Did not find booking for ID " + bookingId);
                });
    }

    public UserDTO findByUsername(String username) {
        logger.debug("Fetching user data for username: {}", username);
        return userClient.findUser(username);
    }

    public EventDTO findById(int id) {
        logger.debug("Fetching event data for ID: {}", id);
        return eventClient.eventData(id);
    }

    public double getTotal(Booking booking) {
        logger.debug("Calculating total for booking");
        return 0;
    }

    public Booking findBookingByEventName(String eventName) throws BookingNotFoundException {
        logger.debug("Searching for booking by event name: {}", eventName);
        return bookRepo.findByEventName(eventName)
                .orElseThrow(() -> {
                    logger.error("Booking not found for event name: {}", eventName);
                    return new BookingNotFoundException("Did not find booking for event name! " + eventName);
                });
    }

//    public EventDTO setQuantity(int id, int quantity) {
//        logger.info("Reducing seat count by {} for event ID: {}", quantity, id);
//        EventDTO eventDto = eventClient.eventData(id);
//        EventDTO result = eventClient.updateSeats(eventDto, quantity);
//        return result;
//    }
}