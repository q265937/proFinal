package com.booking.dto;

public enum RoleDTO {
	USER;
}
